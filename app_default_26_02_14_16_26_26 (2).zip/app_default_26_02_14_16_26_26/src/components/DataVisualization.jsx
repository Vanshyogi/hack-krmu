import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, ScatterChart, Scatter, PieChart, Pie, Cell, Legend
} from 'recharts';

const COLORS = ['#0ea5e9', '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b', '#10b981'];

export default function DataVisualization({ viz, data }) {
  if (!viz || !data || data.length === 0 || viz.type === 'none') return null;

  const renderChart = () => {
    switch (viz.type) {
      case 'bar':
        return (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey={viz.x_axis} />
            <YAxis />
            <Tooltip />
            <Bar dataKey={viz.y_axis} fill="#0ea5e9" radius={[4, 4, 0, 0]} />
          </BarChart>
        );
      case 'line':
        return (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey={viz.x_axis} />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey={viz.y_axis} stroke="#6366f1" strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        );
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={data}
              dataKey={viz.y_axis}
              nameKey={viz.x_axis}
              cx="50%"
              cy="50%"
              outerRadius={80}
              label
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        );
      case 'scatter':
        return (
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey={viz.x_axis} />
            <YAxis dataKey={viz.y_axis} />
            <Tooltip cursor={{ strokeDasharray: '3 3' }} />
            <Scatter name="Data" data={data} fill="#0ea5e9" />
          </ScatterChart>
        );
      default:
        return <p className="text-slate-500 italic">Unsupported chart type.</p>;
    }
  };

  return (
    <div className="w-full h-72 mt-4 bg-slate-50 rounded-lg p-4 border border-slate-100">
      <h4 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider">
        {viz.type} chart: {viz.y_axis} by {viz.x_axis}
      </h4>
      <ResponsiveContainer width="100%" height="100%">
        {renderChart()}
      </ResponsiveContainer>
    </div>
  );
}
