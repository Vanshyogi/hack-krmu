import React from 'react';

export default function DataTable({ data }) {
  if (!data || data.length === 0) return null;
  
  const columns = Object.keys(data[0]);

  return (
    <div className="mt-4 overflow-x-auto border border-slate-200 rounded-lg shadow-sm bg-white">
      <table className="min-w-full divide-y divide-slate-200">
        <thead className="bg-slate-50">
          <tr>
            {columns.map((col) => (
              <th
                key={col}
                className="px-4 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider"
              >
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-slate-100">
          {data.slice(0, 10).map((row, idx) => (
            <tr key={idx} className="hover:bg-slate-50 transition-colors">
              {columns.map((col) => (
                <td key={col} className="px-4 py-2 whitespace-nowrap text-sm text-slate-700">
                  {typeof row[col] === 'object' ? JSON.stringify(row[col]) : String(row[col])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {data.length > 10 && (
        <div className="px-4 py-2 text-xs text-slate-400 italic">
          Showing first 10 rows of {data.length} results
        </div>
      )}
    </div>
  );
}
