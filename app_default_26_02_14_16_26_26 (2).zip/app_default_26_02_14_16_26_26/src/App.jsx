import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { 
  Send, Database, Loader2, Upload, FileText, 
  Terminal, BarChart2, CheckCircle2, AlertCircle 
} from 'lucide-react';
import DataVisualization from './components/DataVisualization';
import DataTable from './components/DataTable';

const API_BASE = '/api';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [schema, setSchema] = useState(null);
  const chatEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const { data } = await axios.post(`${API_BASE}/upload`, formData);
      setSchema(data.schema);
      setMessages(prev => [...prev, {
        type: 'ai',
        content: `Successfully uploaded **${data.table_name}**! You can now start querying this data using natural language.`,
        isSystem: true
      }]);
    } catch (err) {
      alert("Error uploading file: " + err.response?.data?.detail || err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { type: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const { data } = await axios.post(`${API_BASE}/chat`, { message: userMessage });
      setMessages(prev => [...prev, {
        type: 'ai',
        content: data.explanation,
        sql: data.sql,
        resultData: data.data,
        viz: data.visualization
      }]);
    } catch (err) {
      setMessages(prev => [...prev, {
        type: 'ai',
        content: `Sorry, I encountered an error: ${err.response?.data?.detail || err.message}`,
        isError: true
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center z-10">
        <div className="flex items-center gap-3">
          <div className="bg-brand-500 p-2 rounded-lg">
            <Database className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Database Co-pilot</h1>
            <p className="text-xs text-slate-500">DuckDB + AI Natural Language SQL</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept=".csv" 
            onChange={handleFileUpload}
          />
          <button 
            onClick={() => fileInputRef.current.click()}
            disabled={uploading}
            className="flex items-center gap-2 bg-white border border-slate-300 hover:border-brand-500 transition-colors px-4 py-2 rounded-lg text-sm font-medium"
          >
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            Upload CSV
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Chat Section */}
        <section className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto opacity-60">
                <FileText className="w-16 h-16 text-slate-300 mb-4" />
                <h2 className="text-xl font-semibold text-slate-700">Ready to Analyze</h2>
                <p className="text-slate-500 mt-2">Upload a CSV file and ask questions like "What are my total sales by month?" or "List the top 5 customers."</p>
              </div>
            )}
            
            {messages.map((msg, idx) => (
              <div 
                key={idx} 
                className={`flex flex-col ${msg.type === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div className={msg.type === 'user' ? 'chat-bubble-user' : 'chat-bubble-ai'}>
                  {msg.isError && <AlertCircle className="w-4 h-4 text-red-500 inline mr-2" />}
                  <span className="whitespace-pre-wrap">{msg.content}</span>
                  
                  {msg.sql && (
                    <div className="mt-3 bg-slate-900 rounded-md p-3 text-brand-100 font-mono text-xs overflow-x-auto border border-slate-700">
                      <div className="flex justify-between items-center mb-1 text-slate-500 font-sans">
                        <span>GENERATED SQL</span>
                        <Terminal className="w-3 h-3" />
                      </div>
                      {msg.sql}
                    </div>
                  )}

                  {msg.viz && msg.resultData && (
                    <DataVisualization viz={msg.viz} data={msg.resultData} />
                  )}

                  {msg.resultData && msg.resultData.length > 0 && (
                     <DataTable data={msg.resultData} />
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="chat-bubble-ai flex items-center gap-2 italic text-slate-400 bg-transparent border-none shadow-none">
                <Loader2 className="w-4 h-4 animate-spin text-brand-500" />
                Processing query...
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 bg-white border-t border-slate-200">
            <div className="max-w-4xl mx-auto flex gap-3">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={schema ? "Ask about your data..." : "Please upload a CSV file..."}
                disabled={!schema || loading}
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-500 focus:outline-none disabled:opacity-50"
              />
              <button 
                onClick={handleSend}
                disabled={!schema || loading || !input.trim()}
                className="bg-brand-600 hover:bg-brand-700 disabled:bg-slate-300 text-white p-3 rounded-xl transition-all"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </section>

        {/* Sidebar - Schema View */}
        <aside className="w-80 bg-white border-l border-slate-200 overflow-y-auto hidden md:block">
          <div className="p-6">
            <h3 className="text-sm font-bold uppercase text-slate-400 tracking-wider mb-4 flex items-center gap-2">
              <Database className="w-4 h-4" /> Current Schema
            </h3>
            {schema ? (
              <div className="bg-slate-50 rounded-lg p-4 font-mono text-xs whitespace-pre-wrap text-slate-600 border border-slate-100 leading-relaxed">
                {schema}
              </div>
            ) : (
              <div className="text-slate-400 text-sm italic">
                No tables loaded yet. Upload a CSV to get started.
              </div>
            )}
          </div>
        </aside>
      </main>
    </div>
  );
}

export default App;
