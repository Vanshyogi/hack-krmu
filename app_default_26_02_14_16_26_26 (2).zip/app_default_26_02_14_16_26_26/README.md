# Database Co-pilot

A powerful tool to query CSV files using natural language. This application combines **FastAPI**, **DuckDB**, **LangChain (OpenAI)**, and **React** to provide an intuitive interface for data analysis and visualization.

## Features
- **Instant CSV Ingestion**: High-speed loading of CSV files using DuckDB.
- **Natural Language SQL**: Ask questions in plain English and see the generated SQL.
- **Dynamic Charting**: Automatically generates Bar, Line, Pie, or Scatter charts using Recharts.
- **Data Browser**: Preview query results in a responsive data table.
- **Natural Language CRUD**: Perform updates, deletes, and complex aggregations through chat.

## Prerequisites
- **Python 3.9+**
- **Node.js 18+**
- **OpenAI API Key** (for NL2SQL capability)

## Installation & Setup

### 1. Backend Setup
    cd backend
    pip install -r requirements.txt

Create a `.env` file in the root directory (or inside the backend folder) and add your OpenAI key:
    OPENAI_API_KEY=your_key_here

### 2. Frontend Setup
    # In a separate terminal
    npm install

## Running the Application

### 1. Start Backend
From the root directory:
    uvicorn backend.main:app --reload --port 8000

### 2. Start Frontend
From the root directory:
    npm run dev

The application will be available at `http://localhost:3000`.

## How to Use
1. **Upload CSV**: Click the "Upload CSV" button in the header. Use any CSV (e.g., sales statistics, user data).
2. **Review Schema**: The right sidebar will update with the table structure.
3. **Query**: Type questions in the chat box. Examples:
    - "Show me the top 10 rows from the table"
    - "What is the average price grouped by category?"
    - "Update the status of item #123 to 'Shipped'"
    - "Chart the daily revenue for the last month as a line graph"

## Project Structure
- `backend/main.py`: FastAPI endpoints and file handling.
- `backend/ai_service.py`: LangChain integration for SQL generation.
- `backend/db_manager.py`: DuckDB abstraction layer.
- `src/components/DataVisualization.jsx`: Dynamic Recharts logic.
- `src/components/DataTable.jsx`: Tailwind-styled data viewer.
