import os
import shutil
import uuid
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from .db_manager import db_manager
from .ai_service import ai_service

app = FastAPI(title="Database Co-pilot API")

# Enable CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "temp_uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

class ChatRequest(BaseModel):
    message: str

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    
    file_id = str(uuid.uuid4())[:8]
    temp_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file.filename}")
    
    with open(temp_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    try:
        table_name = file.filename.split('.')[0]
        actual_table_name = db_manager.load_csv(temp_path, table_name)
        return {
            "status": "success", 
            "table_name": actual_table_name,
            "schema": db_manager.get_schema()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

@app.post("/chat")
async def chat_endpoint(request: ChatRequest):
    schema = db_manager.get_schema()
    if not schema:
        return {"response": "Please upload a CSV file first.", "data": [], "viz": None}

    try:
        # 1. AI transforms NL to SQL
        ai_response = await ai_service.generate_sql(request.message, schema)
        
        if "error" in ai_response:
             raise HTTPException(status_code=500, detail=ai_response["error"])

        sql = ai_response["sql"]
        
        # 2. Execute SQL
        data = db_manager.execute_query(sql)
        
        return {
            "sql": sql,
            "explanation": ai_response.get("explanation", ""),
            "data": data,
            "visualization": ai_response.get("visualization"),
            "is_mutation": ai_response.get("is_mutation", False)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
