import duckdb
import pandas as pd
import os

class DatabaseManager:
    def __init__(self):
        self.conn = duckdb.connect(database=':memory:')
        self.table_names = []

    def load_csv(self, file_path: str, table_name: str):
        """Loads a CSV file into a DuckDB table."""
        try:
            # Clean table name
            safe_name = "".join(c for c in table_name if c.isalnum() or c == '_').lower()
            self.conn.execute(f"CREATE OR REPLACE TABLE {safe_name} AS SELECT * FROM read_csv_auto('{file_path}')")
            if safe_name not in self.table_names:
                self.table_names.append(safe_name)
            return safe_name
        except Exception as e:
            raise Exception(f"Failed to load CSV: {str(e)}")

    def get_schema(self):
        """Returns the schema of all loaded tables for the LLM context."""
        schema_info = ""
        for table in self.table_names:
            df = self.conn.execute(f"DESCRIBE {table}").df()
            schema_info += f"Table: {table}\nColumns:\n"
            for _, row in df.iterrows():
                schema_info += f"- {row['column_name']} ({row['column_type']})\n"
        return schema_info

    def execute_query(self, sql: str):
        """Executes a SQL query and returns results as list of dicts."""
        try:
            # Security: Basic check to prevent some malicious ops if desired, 
            # though CRUD is explicitly requested.
            res = self.conn.execute(sql)
            if res.description is not None:
                df = res.df()
                return df.to_dict(orient='records')
            else:
                return [{"message": "Command executed successfully"}]
        except Exception as e:
            raise Exception(f"SQL Execution Error: {str(e)}")

db_manager = DatabaseManager()
