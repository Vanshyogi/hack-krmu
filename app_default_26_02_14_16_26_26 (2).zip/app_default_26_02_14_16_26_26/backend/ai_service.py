import os
import json
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from dotenv import load_dotenv

load_dotenv()

class AIService:
    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        
        self.llm = ChatOpenAI(
            model="gpt-4-1106-preview",
            temperature=0,
            api_key=api_key
        )

    async def generate_sql(self, user_query: str, schema: str):
        """Transforms natural language to DuckDB SQL and determines visualization needs."""
        
        system_prompt = """
        You are an expert Data Analyst using DuckDB SQL. Given a database schema and a user request, generate a valid SQL query.
        
        CRITICAL RULES:
        1. Only return valid DuckDB SQL.
        2. If the user wants to update, delete, or insert, generate the appropriate DML statement.
        3. Determine the best visualization type for the result. Options: 'bar', 'line', 'scatter', 'pie', or 'none'.
        4. Predict the x-axis and y-axis column names if a chart is needed.
        5. Return your response STRICTLY as a JSON object.

        Schema Context:
        {schema}

        Example JSON format:
        {{
            "sql": "SELECT region, SUM(sales) as total_sales FROM sales_data GROUP BY region",
            "explanation": "Summarizing total sales by region.",
            "visualization": {{
                "type": "bar",
                "x_axis": "region",
                "y_axis": "total_sales"
            }},
            "is_mutation": false
        }}
        """

        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("user", "{query}")
        ])

        chain = prompt | self.llm
        
        response = await chain.ainvoke({
            "schema": schema,
            "query": user_query
        })

        try:
            # Clean the response in case LLM adds markdown backticks
            content = response.content.replace('